import torch
from torch import nn
# from model.non_resnet import ResNet50, Bottleneck
# from model.conformer import Conformer_small_patch32
# from model.conformer import Conformer_small_patch16
# from model.conformer import Conformer_tiny_patch16
from resnet3d import resnet50


class Enhance_models(nn.Module):
    def __init__(self,args):
        super(Enhance_models, self).__init__()

        # self.query = ResNet50(pretrained=False, non_local=True)
        # # print(self.query)
        # self.target =ResNet50(pretrained=False, non_local=True)
        # # print(self.target)
        # self.query = Conformer_tiny_patch16(pretrained=False)
        # # print(self.query)
        # self.target = Conformer_tiny_patch16(pretrained=False)
        # print(self.target)
        # self.Enhance = selfattention(256, 256)
        self.query = resnet50(args)
        # print(self.query)
        self.target = resnet50(args,rga_mode=True)

        # 全连接层
        # self.avgpool = nn.AvgPool2d(8)
        # self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)  # 1 / 4 [56, 56]
        # self.fc = nn.Linear(2048, 1)
        self.dropout = nn.Dropout(0.15)
        self.fc = nn.Linear(1024, 1)
        # self.fc = nn.Linear(512 * block.extention)

    def forward(self, golbal, local):
        L_map = self.query(local)
        # print('L_map', L_map.shape)
        G_map = self.target(golbal)
        # print('G_map', G_map.shape)
        # out_enhance = Q_map+KV_map
        # print("1.out",out_enhance.shape)
        w1=torch.sigmoid(L_map*G_map)
        GL_map=(w1+1)*G_map
        # print('GL_map', GL_map.shape)
        Wgl=torch.sigmoid((GL_map+L_map)*(GL_map+G_map))
        # print('Wgl', Wgl.shape)
        GL=Wgl*(GL_map+L_map)+Wgl*(GL_map+G_map)
        # print('GL', GL.shape)
        # out_gap = self.maxpool(out_enhance)
        # print("out_gap",out_gap.shape)
        # out_flatten = torch.flatten(out_gap, 1)  # 1表示维度
        # print("out_flatten", out_flatten.shape)
        out_fc = self.fc(GL)
        out = self.dropout(out_fc)
        # out = torch.squeeze(out)
        # print("4.out",out.shape)

        return out


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()

    """
    data setting
    """
    parser.add_argument('--resize', default=128, type=int, metavar='N')
    parser.add_argument('--clip_len', default=16, type=int, metavar='N')
    parser.add_argument('--loads', default=[30, 60, 90, 400], type=str)
    args = parser.parse_args()
    model = Enhance_models(args)
    # Resnet
    # resnet = ResNet(Bottleneck, [3, 4, 6, 3])
    p = sum(map(lambda p: p.numel(), model.parameters()))
    print('parameters size:', p)
    # x = torch.randn(3, 3, 256, 256)
    # y = torch.randn(3, 3, 256, 256)
    # x1 = model(x, y)
    # print(x1.shape)

    from thop import profile
    x = torch.randn(1, 3,16, 128, 128)
    y = torch.randn(1, 3,16, 128, 128)
    # x1 = model(x, y)
    # input = torch.randn(1, 3, 224, 224)
    flops, params = profile(model, inputs=(x,y,))
    print(flops)
    print(params)
    pass
